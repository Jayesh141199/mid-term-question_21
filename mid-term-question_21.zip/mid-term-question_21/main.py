import math

class Point:
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

class Segment:
    def __init__(self, p1, p2):
        self.p1 = p1
        self.p2 = p2

    def length(self):
        return math.sqrt((self.p2.x - self.p1.x) ** 2 + (self.p2.y - self.p1.y) ** 2)

    def slope(self):
        try:
            return (self.p2.y - self.p1.y) / (self.p2.x - self.p1.x)
        except ZeroDivisionError:
            return None  


p1 = Point(10, 32)
p2 = Point() 
s = Segment(p1, p2)

print(s.length())
print(s.slope())